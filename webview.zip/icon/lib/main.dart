import 'package:flutter/material.dart';

import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(webview_app());
}

class webview_app extends StatefulWidget {
  const webview_app({super.key});

  @override
  State<webview_app> createState() => _webview_appState();
}

class _webview_appState extends State<webview_app> {
  // after plunge add khud banana
  late int currentIndex = 0;
  late WebViewController controller;
  List<String> urls = [
    "https://www.all-available.com/",
    "https://www.all-available.com/shop/"
  ];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //website sy copy krna
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
            onPageStarted: (a) {}, onProgress: (a) {}, onPageFinished: (a) {}),
      );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Web View app"),
        ),
        body: WebViewWidget(controller: controller),
        bottomNavigationBar: BottomNavigationBar(
          onTap: (index) {
            setState(() {
              currentIndex = currentIndex;
              controller.loadRequest(Uri.parse(urls[index]));
            });
          },
          backgroundColor: Colors.yellowAccent,
          currentIndex: currentIndex,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
            BottomNavigationBarItem(icon: Icon(Icons.shop), label: "Shop"),
          ],
        ),
      ),
    );
  }
}
